export const superHeros = [
  { name: "Superman", power: ["Fly", "Super Strength"] },
  { name: "Hulk", power: ["Super Strength", "Regeneration"] },
  {
    name: "IronMan",
    power: ["Intelligence", "Technology", "Fly", "Billionaire"],
  },
  { name: "SpiderMan", power: ["Agility", "Spider-Sense"] },
  { name: "CaptainAmerica", power: ["Leadership", "Super Strength"] },
  { name: "BlackWidow", power: ["Agility", "Intelligence"] },
  { name: "GreenLantern", power: ["Energy Manipulation", "Fly"] },
  { name: "Wolverine", power: ["Regeneration", "Claws"] },
  { name: "Thor", power: ["Thunder Control", "Super Strength"] },
  { name: "Batman", power: ["Intelligence", "Martial Arts", "Billionaire"] },
  { name: "Flash", power: ["Super Speed", "Time Travel"] },
  { name: "WonderWoman", power: ["Super Strength", "Agility", "Fly"] },
  // { name: "Aquaman", power: ["Water Control", "Super Strength"] },
];
